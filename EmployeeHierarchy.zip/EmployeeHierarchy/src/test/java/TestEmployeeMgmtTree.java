import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * Test Class for EmployeeManagementTree
 */
public class TestEmployeeMgmtTree {
    private EmployeeMgmtTree empMgmtTree;
    private OutputStream os = new ByteArrayOutputStream();
    private PrintStream ps = new PrintStream(os);

    @Before
    public void setUp() {
        empMgmtTree = new EmployeeMgmtTree();
        System.setOut(ps);
    }

    @Test
    public void testPopulateEmployeeData() {
        empMgmtTree.populateEmployeeData();
        assertFalse(empMgmtTree.getEmployeeList().size() == 0);

    }

    @Test
    public void testBuildEmployeeTree() {
        List<Employee> empRecords = Arrays.asList(new Employee(1, "Tom", 0), new Employee(2, "Mickey", 1));
        empMgmtTree.setEmployeeList(empRecords);
        Employee emp = new Employee(1, "Tom", 0);
        empMgmtTree.buildEmployeeBranch(emp);
        assertNotNull(emp.getReportees());
        Employee emp1 = new Employee(2, "Mickey", 1);
        empMgmtTree.buildEmployeeBranch(emp1);
        assertNull(emp1.getReportees());
    }

    @Test
    public void testDisplayManagementTree() {
        List<Employee> empRecords = new ArrayList<Employee>() {{
            add(new Employee(1, "Tom", 0));
        }};
        empMgmtTree.setEmployeeList(empRecords);
        empMgmtTree.displayManagementTree();
        assertEquals("->Tom" + "\n", os.toString());

    }

    @Test
    public void testDisplayManagementTree1() {
        List<Employee> empRecords = Arrays.asList(new Employee(1, "Tom", 0), new Employee(2, "Mickey", 1));
        empMgmtTree.setEmployeeList(empRecords);
        empMgmtTree.displayManagementTree();
        assertEquals("->Tom\n->->Mickey\n", os.toString());
    }

    @After
    public void tearDown() {
        empMgmtTree = null;
        PrintStream originalOut = System.out;
        System.setOut(originalOut);
    }
}
