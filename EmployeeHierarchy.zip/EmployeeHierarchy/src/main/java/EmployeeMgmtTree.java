import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Class to hold the functionality related to Employee Management Tree.
 */
public class EmployeeMgmtTree {
    private List<Employee> employeeList = new LinkedList<>();

    List<Employee> getEmployeeList() {
        return employeeList;
    }

    void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    //Method to temporarily populate the employee records.
    void populateEmployeeData() {
        //logic to populate the map with the employee records.
        List<Employee> empDataList = getEmployeeList();
        empDataList.add(new Employee(1, "Tom", 0));
        empDataList.add(new Employee(2, "Mickey", 1));
        empDataList.add(new Employee(3, "Jerry", 1));
        empDataList.add(new Employee(4, "John", 2));
        empDataList.add(new Employee(5, "Sarah", 1));
        setEmployeeList(empDataList);

    }

    //build the employee tree provided with the employee to start with
    void buildEmployeeBranch(Employee employee) {
        //retrieve the list of reporting employees to this employee.
        List<Employee> reportees = getEmployeeList().stream()
                .filter(e -> e.getEmpReportToId().equals(employee.getEmpId()))
                .sorted(Comparator.comparing(Employee::getEmpName))
                .collect(Collectors.toList());
        if (reportees.size() != 0) {
            employee.setHasReportees(true);
            employee.setReportees(reportees);
            reportees.forEach(this::buildEmployeeBranch);
        }
    }

    // print employee tree provided an employee and his level in the hierarchy.
    private void printEmployeeBranch(Employee emp, int level) {
        IntStream.range(0, level).forEach(i -> System.out.print("->"));
        System.out.print(emp.getEmpName() + "\n");
        if (emp.hasReportees()) {
            emp.getReportees().forEach(e -> printEmployeeBranch(e, level + 1));
        }
    }

    //print the Employee Tree
    void displayManagementTree() {
        //figure out the root employee(emp with manager id as 0)
        Employee employeesHead = getEmployeeList().stream().filter(e -> e.getEmpReportToId() == 0).findFirst().orElse(null);
        if (employeesHead != null) {
            buildEmployeeBranch(employeesHead);
            //start printing from employee head level
            printEmployeeBranch(employeesHead, 1);
        }
    }

    public static void main(String[] args) {
        EmployeeMgmtTree empTree = new EmployeeMgmtTree();
        empTree.populateEmployeeData();
        empTree.displayManagementTree();
    }
}
