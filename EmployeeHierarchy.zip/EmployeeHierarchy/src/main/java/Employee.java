import java.util.List;

/**
 * javabean to hold the Employee Details.
 */
public class Employee {
    private Integer empId;
    private String empName;
    private Integer empReportToId;
    private boolean hasReportees = false;
    private List<Employee> reportees;

    public Employee(Integer empId, String empName, Integer empReportToId){
        this.empId = empId;
        this.empName = empName;
        this.empReportToId = empReportToId;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Integer getEmpReportToId() {
        return empReportToId;
    }

    public boolean hasReportees() {
        return hasReportees;
    }

    public void setHasReportees(boolean hasReportees) {
        this.hasReportees = hasReportees;
    }

    public void setEmpReportToId(Integer empReportToId) {
        this.empReportToId = empReportToId;
    }

    public List<Employee> getReportees() {
        return reportees;
    }

    public void setReportees(List<Employee> reportees) {
        this.reportees = reportees;
    }
}
